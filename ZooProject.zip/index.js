const express = require('express');

const app = express();
const mongoose = require('mongoose');
const cors = require('cors');

app.use(cors());

//Import Routes
const getanimals = require('./getAnimals');

app.use('/animals', getanimals);

//Connect to DB
//mongoose.connect('mongodb+srv://mkieffer:Aspenparks12@cluster0.t6jua.mongodb.net/test?retryWrites=true&w=majority',
//    { useNewUrlParser: true},
//    () => console.log('connected to DB')
//);

app.listen(3000);